// zadanie 5: Wykona� "Exercise 10" ze strony 86 w ksi��ce.
// Write a program that takes an operation followed by two operands and
// outputs the result. For example:
// + 100 3.14
// * 4 5
// Read the operation into a string called operation and use an
// if-statement to figure out which operation the user wants, for example,
// if (operation=="+"). Read the operands into variables of type double.
// Implement this for operations called +, �, *, /, plus, minus, mul, and div
// with their obvious meanings.

#include "std_lib_facilities.hpp"

int main()
{
	string o;
	float a;
	float b;

	cout << "Wpisz: Rodzaj operacji-->spacja-->wart1-->spacja-->wart2" << "\n";
	cin >> o >> a >> b;

	cout << "Twoje dzia�enie: " << "\n";
	if (o == "+")
	{
		cout << a + b << "\n";
	}
	if (o == "plus")
	{
		cout << a + b << "\n";
	}

	if (o == "-")
	{
		cout << a - b << "\n";
	}
	if (o == "minus")
	{
		cout << a - b << "\n";
	}
	if (o == "*")
	{
		cout << a*b << "\n";
	}
	if (o == "mul")
	{
		cout << a*b << "\n";
	}
	if (o == "/")
	{
		cout << a / b << "\n";
	}
	if (o == "div")
	{
		cout << a / b << "\n";
	}



	system("pause");
}