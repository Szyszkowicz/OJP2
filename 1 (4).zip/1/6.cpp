// zadanie 2: Wykona� "Drill" ze strony 83 w ksi��ce.

#include "std_lib_facilities.hpp"

int main()
{
	cout << "Please enter the name of the person you want to write to:\n";
	string first_name;
	string friend_name;
	char friend_sex;
	int age;
	cin >> first_name;

	cout << "Please enter the name of your second friend\n";
	cin >> friend_name;

	cout << "Please enter sex of your friend\n";
	cin >> friend_sex;

	cout << "Please enter age of your friend\n";
	cin >> age;

	cout << "Dear " << first_name << "\n\n\n\n\n\n";
	cout << "How are you? I am fine. I miss you\n";
	cout << "Have you seen " << friend_name << " lately?\n";

	if (friend_sex == 'f')
	{
		cout << "If you see " << friend_name << " please ask her to call me.\n";
	}

	if (friend_sex == 'm')
	{
		cout << "If you see " << friend_name << " please ask him to call me.\n";
	}
	cout << "I hear you just had a birthday and you are " << age << " years old.";

	if (age <= 0) {
		simple_error(" you're kidding! You don't born?");

	}
	else if (age >= 110) {

		simple_error(" you're kidding! You are so old...");

	}
	else if (age < 12) {
		cout << "Next year you will be " << age + 1;

	}
	else if (age == 17) {
		cout << "Next year you will be able to vote.";
	}
	else if (age > 70) {
		cout << "I hope you are enjoying retirement.";
	}

	cout << "\n\n\n\n\nYours sincerely, Marcin\n\n\n";

	system("pause");
}


