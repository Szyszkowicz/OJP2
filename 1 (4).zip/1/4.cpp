// zadanie 4: Wykonać "Exercise 6 oraz 7" ze strony 86 w książce.
// 6. Write a program that prompts the user to enter three integer values, and
// then outputs the values in numerical sequence separated by commas. So,
// if the user enters the values 10 4 6, the output should be 4, 6, 10. If two
// values are the same, they should just be ordered together. So, the input
// 4 5 4 should give 4, 4, 5.
// 7. Do exercise 6, but with three string values. So, if the user enters the val-
// ues Steinbeck, Hemingway, Fitzgerald, the output should be Fitzgerald,
// Hemingway, Steinbeck.

#include "std_lib_facilities.hpp"


int main()
{

	string a;
	string b;
	string c;
	cout << "Wpisz liczby rozdzielone spacj�\n";
	cin >> a;
	cin >> b;
	cin >> c;

	cout << "Wartosc 1: " << a << "," << "Wartosc 2: " << b << "," << "Wartosc 3: " << c << " \n";

	cout << "Ciag posortowanych liczb: " << " \n";

	if ((a <= b) && (a <= c))
	{
		cout << a << ",";
		if (b <= c) {
			cout << b << "," << c << "\n";
		}
		else
		{
			cout << c << "," << b << "\n";
		}
	}
	else if ((b <= c) && (b <= a)) {
		cout << b << ",";
		if (a <= c) {
			cout << a << "," << c << "\n";
		}
		else {
			cout << c << "," << a << "\n";
		}
	}
	else if ((c <= b) && (c <= a)) {
		cout << c << ",";
		if (b <= a) {
			cout << b << "," << a << "\n";
		}
		else {
			cout << a << "," << b << "\n";
		}
	}



	system("pause");
}
